<template>
    <div>
      <h2>Manage Bookings</h2>
      <p>Admins can update booking status. Managers can view bookings for their hotels only.</p>
      <!-- Booking list and actions go here -->
    </div>
  </template>
  